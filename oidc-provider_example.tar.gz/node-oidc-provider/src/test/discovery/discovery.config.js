const config = require('../default.config');

module.exports = {
  config,
};
